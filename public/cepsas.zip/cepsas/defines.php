<?php
define ('BASE', $_SERVER['DOCUMENT_ROOT']);//RUTA DE LA CARPETA PRINCIPAL DE MI PROYECTO
define ('URL', 'http://'.$_SERVER['SERVER_NAME'].'/');//LA URL DE MI PROYECTO
define ('B_IMG', BASE .'/img');
define ('B_CSS', URL .'css');
define ('B_TOOLS', BASE . '/tools');
define ('B_TOOLS_JS', URL .'tools/');
define ('B_CONTROLLERS', BASE . '/controllers');
define ('B_HERRAMIENTAS', BASE . '/herramientas');
define ('B_VIEWS', BASE . 'views');
define ('B_IMG_URL', URL .'img/');
define ('B_VIEWS_URL', URL .'views/');
define ('B_JQ', URL .'jquery/');


?>