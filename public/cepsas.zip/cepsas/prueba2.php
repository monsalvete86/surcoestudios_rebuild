<?php
include('tools/controlador.php');
session_start();
echo "xxx";
?>
<table align="center" width="600px"  >
    
        <tr align="center" valign="top">
            <td style="text-align:center;" width="100px" valign="top">
				<img src="logo_pdf.png">
			</td>
            <td style="text-align:center ;" width="500px">
				<b><span style="font-size:24px"><?php echo "xx"?> C.E.P  S.A.S.</span></b><br>
				<b>EL CENTRO DE EDUCACION PETROLERA</b><br>
				<i>Nit. 900.513.118-7 Registro Mercantil 45541-16<br>Permiso Sercretar&iacute;a de Educaci&oacute;n</i>
			</td>
           
        </tr>					    
	<tr>
		<td colspan="2">
			<table border="1" align="center" width="580px">
				<tr>
					<td>Alumno:</td><td colspan="3"></td>
				</tr>
				<tr>
					<td>Identifiacion:</td><td></td>
					<td>Curso</td><td>MANEJO DEFENSIVO</td>
				</tr>
				<tr>
					<td>Resultado</td>
					<td></td>
					<td>Estado</td>
					<td></td>
				</td>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<table align="center" width="580px" border="1" style="font-size:12px">	
				
				<tr>
					<td width="15px" style="text-align:center"><b><span style="font-size:10px">No.</span></b></td>
					<td width="520px" colspan="2" style="text-align:center"><b><span style="font-size:10px">Pregunta</span></b></td>
					<td width="20px"><b><span style="font-size:10px">Rspta</span></b>
				</tr>
				
				<tr>
					<td width="15px" valign="middle"><b>1.</b></td>
					<td colspan="3"><span style="font-size:10px">&iquest;Qu&eacute; es el manejo defensivo?</span></td>
				</tr>
				<tr><td></td>
					<td colspan="2">
					<b>a.</b>
					<span style="font-size:10px">Es un conjunto de procedimientos y t&eacute;cnicas establecidos que el conductor debe seguir para manejar de forma segura.
						</span><br>
					<b>b. </b>					
						<span style="font-size:10px">
							Es el conjunto de normas para defenderme de los conductores que quieren atacarme.
						</span>		<br>				
					<b>c.</b>					
						<span style="font-size:10px">
							Es la forma de conducir m&aacute;s peligrosa que hay.
						</span>	
					
					<td width="15px">rta</td>
				</tr>
				<tr>
					<td width="15px" valign="middle"><b>2.</b></td>
					<td colspan="3"><span style="font-size:10px">&iquest;Cu&aacute;les son los 3 factores que influyen en la seguridad vial?</span></td>
				</tr>
				<tr><td></td>
					<td colspan="2">
					<b>a.</b>
						<span style="font-size:10px">Social / Psicol&oacute;gico /Econ&oacute;mico.</span><br>
					<b>b. </b>					
						<span style="font-size:10px">Natural / Vial / Com&uacute;n.</span><br>
					<b>c.</b>					
						<span style="font-size:10px">Humano / Veh&iacute;culo / Condiciones adversas del ambiente.</span>					
					<td width="15px">rta</td>
				</tr>
								
				<tr>
					<td colspan="4"><b>En las siguientes preguntas conteste (F) si es falso y (V) si es verdadera la afirmaci&oacute;n.</b></td>
				</tr>
				<tr>
					<td width="15px" valign="middle"><b>3.</b></td>
					<td colspan="3">
						<span style="font-size:10px">
							Un conductor que se sienta cansado, podr&aacute; mejorar si se toma una pastilla y una bebida energetizante.
						</span></td>
					</td>
				</tr>
				<tr><td></td>				
					<td colspan="2">
						<b>- F</b><br><b>- V</b>	
					</td>
					<td width="15px">rta</td>
				</tr>
				<tr>
					<td width="15px" valign="middle"><b>4.</b></td>
					<td colspan="3">
						<span style="font-size:10px">
							Los siguientes son distracciones al conducir: fumar, escuchar la radio y contemplar el paisaje.
						</span></td>
					</td>
				</tr>
				<tr><td></td>				
					<td colspan="2">
						<b>- F</b><br><b>- V</b>	
					</td>
					<td width="15px">rta</td>
				</tr>
				<tr>
					<td width="15px" valign="middle"><b>5.</b></td>
					<td colspan="3">
						<span style="font-size:10px">
							Los siguientes son distracciones al conducir: fumar, escuchar la radio y contemplar el paisaje.
						</span></td>
					</td>
				</tr>
				<tr><td></td>				
					<td colspan="2">
						<b>- F</b><br><b>- V</b>	
					</td>
					<td width="15px">rta</td>
				</tr>
			</table>
		</td>
	</tr>
</table>	

