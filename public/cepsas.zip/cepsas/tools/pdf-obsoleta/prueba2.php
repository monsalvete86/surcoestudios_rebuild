<table>
    <thead>
        <tr>
            <th style="text-align:left;">Nombre</th>
            <th style="text-align:left;">Apellido</th>
            <th style="text-align:left;">Sexo</th>
            <th style="text-align:left;">Nacimiento</th>
        </tr>
    </thead>
</table>	