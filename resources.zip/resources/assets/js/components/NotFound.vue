<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mt-4">
                <h3> Panel de administración </h3>
                
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
           
        }
    }
</script>
